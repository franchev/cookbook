#!/usr/bin/python
#
import os
import sys
import logging 

def getLogger(name, filename=None):
  """
  Get a Permabit-compliant logger object.

  Optional parameter: filename. 
  """
  logger = logging.getLogger(name)
  logger.setLevel(logging.DEBUG)
  # the format. 
  # timestamp. Log level. Module name. Message
  formatter = logging.Formatter(
    '%(asctime)s - %(levelname)s-%(name)s-[%(process)d] %(message)s')
  handler = logging.StreamHandler()
  handler.setLevel(logging.DEBUG)
  handler.setFormatter(formatter)
  logger.addHandler(handler)
  if filename: 
    fhandler = logging.FileHandler(filename)
    fhandler.setFormatter(formatter)
    logger.addHandler(fhandler)
  return logger

def main(args): 
  L = getLogger(__name__, "/tmp/foo")
  L.debug("foo")

if __name__ == '__main__':
  main(sys.argv)

