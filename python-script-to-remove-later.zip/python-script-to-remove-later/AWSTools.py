#!/usr/bin/python

import cmd
import datetime
import glob
import logging
import os
import pprint
import re
import shlex
import subprocess
import sys
import time

from optparse import OptionParser
from sets import Set

import boto.ec2
import boto.s3

SCRIPTS_DIR = "/permabit/build/aws/lastrun/scripts"

class PermabitAWS(object):
  """
  Class representing the Permabit AWS
  account, including authentication info,
  SSH keys, and common methods.
  """
  # Obtained from AWSTools.pm
  private_key = "/permabit/ops/ec2/pk-permabit.pem"
  private_cert = "/permabit/ops/ec2/cert-permabit.pem"
  account = "654125576711"

  IMAGE_KERNEL = "aki-88aa75e1"
  ACCESS_KEY = 'AKIAJUHNS3BWFWVW7SNQ'
  SECRET_KEY = '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'
  KEYS = ['-K', private_key, '-C', private_cert]

  def print_keys(self):
    """ Quick lookup for when you have to use ec2-* utils"""
    print ' '.join(KEYS)

  def __init__(self):
    pass

  def s3Connect(self):
    """
    Connect to Amazon's storage.
    """
    self.s3conn = boto.s3.connect_to_region(
      'us-east-1',
      aws_access_key_id=self.ACCESS_KEY,
      aws_secret_access_key=self.SECRET_KEY)

  def ec2Connect(self):
    """
    Connect to Amazon's Ec2 host management.
    """
    self.conn = boto.ec2.connect_to_region(
      'us-east-1',
      aws_access_key_id=self.ACCESS_KEY,
      aws_secret_access_key=self.SECRET_KEY)

  def checkAMI(self, amiName):
    """
    Check to see if the AMI exists by getting the properties for it.

    @param amiName The name of the AMI that is to be checked.

    @return true if the AMI exists, false otherwise.
    """
    filters = {"name": amiName}
    L = self.conn.get_all_images(filters=filters)
    return L

  def checkAMIUpload(self, amiName):
    """
    Check to see if the AMI has been uploaded to the S3 bucket.

    param amiName The name of the AMI that is too be checked.
    (The name assigned to the AMI, not its ID, e.g. rhel6-2015-01-13-00-14)

    return true if the AMI was fully uploaded, false otherwise.
    """
    # The name happens to exist as an S3 bucket.
    B = self.s3conn.get_bucket(amiName)
    # And as per our policy, the bucket contains a key for the manifest file.
    k = B.get_key(amiName + '.manifest.xml')
    # And the manifest file is some XML
    contents = k.get_contents_as_string()
    # If all this checks out, the upload is done, and return True.
    return contents.startswith("<?xml version='1.0'?><manifest>")

  def checkEnvironment(self):
    """
    Check to make sure that the environmental variables have been set
    correctly.

    @return true if the variables have been set, false otherwise.
    """
    return all([os.environ.get(k) for k in
                ["EC2_HOME", "EC2_AMITOOL_HOME",
                 "EC2_PRIVATE_KEY", "EC2_CERT"]])

  def checkInstance(self, name):
    """
    """
    # Get an instance id
    instance = self.getInstanceID(name=name)
    # AWS query.
    if instance.state != 'running':
      return instance.state

    if subprocess.call(["fping", instance.private_ip_address]) == 0:
      return instance.state
    else:
      return "unknown"

  def checkNetworkInterface(self, ipaddr):
    """
    Check to see if the network interface indicated is attached.

    @param ipaddr The network-connection's private IP address

    @return True in the event that the interface is attached , 
    else False
    """
    interfaces = self.conn.get_all_network_interfaces(
      filters={'private_ip_address':ipaddr})
    if len(interfaces) == 0:
      return False
    if len(interfaces) == 1:
      return interfaces[0].status
    raise Exception (len(interfaces) + 
                     ' is too many interfaces for one address')

  def createAMI(self, xenImage, amiPath, amiName):
    """
    Bundle a new AMI. In the event of an error,
    throw an exception with the results of the
    call to ec2-bundle-image.

    @param xenImage The Xen image to be bundled.
    @param amiPath  The AMI path to save the image at.
    @param amiName  The AMI name to use for the image.

    Boto.manage has some barely documented
    convenience functions, but they actually call this
    utility anyway.
    """
    bundlepath = amiPath + '/' + amiName
    # no way to get around making this one a subprocess based one.
    cmd = ['ec2-bundle-image', '--arch', 'x86_64', '--destination',
           '--prefix',
           amiName, '--image', xenImage, '--user', self.account,
           ] + KEYS
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    print p.communicate()
    return p.returncode

  def createTag(self, Id, name, value):
    """
    Add a tag to the indicated resource.

    @param id The id of the resource to add the tag to.
    @param name The name of the tag to be created.
    @param value The value of the tag to be applied.
    """
    return self.conn.create_tags([Id, ], {name: value})

  def deleteTag(self, Id, name):
    """
    Remove a tag from the indicated resource.

    @param id The id of the resource to delete the tag from.
    @param name The name of the tag to be deleted.
    """
    return self.conn.delete_tags([Id, ], [name, ] )

  def deleteS3Bucket(self, bucket):
    """
    Delete the S3 bucket and all of its contents.

    @param bucket The bucket that is to be deleted.
    """
    return self.s3conn.delete_bucket(bucket)

  def deregisterAMI(self, amiName):
    """
    Deregister the AMI from EC2.

    @param amiName The AMI name to be deregistered.
    """
    return self.conn.deregister_image(amiName)

  def getAMIID(self, amiName):
    """
    Get the AMI id that should be used when running commands on the basis
    of the AMI name that is provided.

    param amiName The name of the AMI to retrieve the id of.

    return The id of the AMI or an empty string if the name was not matched.
    (From AMITools)
    """
    L = self.checkAMI(amiName)
    return L[0].id

  def getInstances(self): 
    """
    Get the full list of instances we have at AWS.
    """
    return self.conn.get_only_instances()

  def getImages(self): 
    """
    Get the full list of instances we have at AWS.
    """
    return self.conn.get_all_images()

  def getInstanceDistro(self, instanceId):
    """
    Get the distribution that have been applied to the
    AMI that the instance is running.

    @param instance The Amazon instance id.

    @return The distro that the instance is running.
    """
    instance = self.conn.get_all_instances(
      instance_ids=[instanceId])[0].instances[0]
    imageId = instance.image_id
    image = self.conn.get_all_images(image_ids=[imageId])[0]
    return image.tags['Distro']

  def getDistroAMIs(self, distro):
    """
    Get the list of AMIs that have been registered for the AMI provided.

    @param distro The distribution to get the list for.

    @return A list of AMIs sorted by name.
    """
    return sorted(self.conn.get_all_images(filters={'tag:Distro': distro}),
                  key=lambda x: x.name)

  def getInstanceID(self, name=None, ipaddr=None):
    """
    Get the instanceID for a host from
    the hostname or ip address.
    """
    #
    filters = {}
    if name:
      filters['tag:Name'] = name
    if ipaddr:
      filters['private-ip-address'] = ipaddr

    L = self.conn.get_only_instances(filters=filters)
    if len(L) > 1:
      L = filter (lambda x: x.state != 'terminated',
                  L)
      if len(L) > 1: 
        raise Exception(
          "Multiple instances claiming %s/%s\n%s" % (
            name, ipaddr, L))
    return (L[0] if L else None)

  def registerAMI(self, amiName):
    """
    Register the AMI indicated with EC2.

    @param amiName The AMI name to be assigned to the AMI, this should be
    the same as the S3 bucket that the manifest is contained
    in.

    @return a string with the name of the AMI provided by Amazon.

    """
    return self.conn.register_image(
      image_location=amiName + '/' + amiName + '.manifest.xml',
      architecture="x86_64",
      kernel_id=self.IMAGE_KERNEL)

  def displayInstance(self, instance_id):
    L = self.conn.get_only_instances(instance_ids=[instance_id])
    for i in L:
      print i.id, i.state
      pprint.pprint(i.__dict__)

  def displayInterfaces(self, interface_id=None):
    L = self.conn.get_all_network_interfaces()
    for i in L:
      print i.status
      pprint.pprint(i.__dict__)

  def displayImage(self, image_id):
    L = self.conn.get_all_images(image_ids=[image_id])
    for i in L:
      print i.id, i.name
      pprint.pprint(i.__dict__)

  def resolveInstance(self, instance_id):
    """
    Resolve the instance provided and return either the DNS name to use to
    connect to it or the IP address. In general, the DNS name should be
    returned; however, in the event that the name has not been set correctly
    at Amazon, the IP address will be returned instead. This is done to
    ensure that new systems that may not have a DNS name yet may still be
    managed using these tools.

    @param instance_id The id of the instance
    whose DNS name or IP addess is to be
    resolved.

    @return a string with the DNS name, the IP address, or an empty string
    if the instance cannot be resolved.
    """
    L = self.conn.get_all_instances(instance_ids=[instance_id])
    if not L[0].instances:
      return None

    return (L[0].instances[0].private_dns_name if
            L[0].instances[0].private_dns_name
            else L[0].instances[0].private_ip_address)

  def uploadAMI(self, bundle, amiName):
    """
    Upload the AMI to Amazon, this function will attempt to retry the
    upload
    in the event of an error and can restart uploads that failed.

    @param bundle  The name of the bundle that is to be checked.
    @param amiName The name of the AMI that is too be checked.
    """
    cmd = ["ec2-upload-bundle", "--retry", "--bucket", amiName,
           "--manifest", bundle + '/' + amiName + ".manifest.xml",
           "--access-key", self.ACCESS_KEY,
           "--secret-key", self.SECRET_KEY]
    p = subprocess.Popen(
      cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    print p.communicate()
    return p.returncode

  def launchInstance(self,
                     amiName,
                     count=1,
                     key=None,
                     ip=None,
                     group="sg-8c8e68e3",
                     subnet="subnet-aadd1fc1",
                     instance_type="c1.medium",
                     zone="us-east-1d"):
    """
    Launch an instance of the given type and return the instance.

    @param args{amiName} The name of the AMI to be launched.
    @oparam args{count}  Default 1, number of instances to be launched.
    @oparam args{group}  Default sg-8c8e68e3 (i.e. vpc-quick-start), the
      security group to use when launching the instance.
      This should be empty if the security group is not
      needed.
    @oparam args{ip}     Default empty, the IP address to use.
    @oparam args{key}    Default empty, the SSH key to use.
    @oparam args{subnet} Default subnet-aadd1fc1, the VPC subnet to launch
      the instance in. This should be empty if the
      instance is not being launched in a VPC.
    @oparam args{type}   Default c1.medium, the machine type for the
      instance, in general this should be c1.medium.
    @oparam args{zone}   Default us-east-1d, the zone that the instance
      should be launched to.
    """
    reservation = self.conn.run_instances(amiName,
                                          min_count=count,
                                          max_count=count,
                                          key_name=key,
                                          instance_type=instance_type,
                                          security_group_ids=[group],
                                          placement=zone,
                                          private_ip_address=ip,
                                          subnet_id=subnet)
    instance = reservation.instances[0]
    while True:
      time.sleep(15)
      instance.update()
      if instance.state == "running":
        return instance
      if instance.state == "terminated":
        return self.launchInstance(amiName, count, key, ip, group, 
                                   subnet, instance_type, zone)

  def shutDownHost(self, value):
    """
    Shutdown the instance indicated.

    @param value The value of the instance which can be the IP address,
      instance ID, or the DNS name.
    """
    instance_id = self.getInstanceID(value).id
    self.shutDownInstance(instance_id)

  def shutDownInstance(self, instance_id):
    print "shutting down", instance_id
    return self.conn.terminate_instances(instance_ids=[instance_id])

  def shutDownAndWait(self,
                      instance,
                      wait=15):
    """
    Shut down an instance and wait for it to be fully offline before
    returning.

    @param instance The name of the instance to be shutdown.
    """
    instance_id = self.shutDownInstance(instance)[0]
    until = (datetime.datetime.now() + datetime.timedelta(minutes=wait))
    while True:
      instance = self.getInstanceID(instance)
      if not instance:
        print "DELETED"
        break
      if instance.state == 'terminated':
        print "TERMINATED"
        break
      if datetime.datetime.now() > until:
        print "GAVE UP ON SHUTDOWN"
        sys.exit(1)
      print "sleeping 15"
      time.sleep(15)


class AWSCLI(cmd.Cmd):

  def __init__(self, paws, ):
    self.paws = paws
    cmd.Cmd.__init__(self)

  def process(self, ret):
    pprint.pprint(ret)

  def write(self, s):
    print s

  def do_exit(self, s=''):
    return True

  def can_exit(self):
    return True

  do_EOF = do_q = do_exit

  def do_getInstanceID(self, s):
    """
    gets Instance ID From hostname (tested)
    """
    self.process(self.paws.getInstanceID(s))

  def do_getInstances(self, s):
    """
    gets list of all instances
    """
    self.process(self.paws.getInstances())

  def do_getImages(self, s):
    """
    gets list of all instances
    """
    self.process(self.paws.getImages())

  def do_getInstanceFromIP(self, s):
    """
    Gets Instance ID From hostname (tested)
    """
    self.process(self.paws.getInstanceID(ipaddr=s))

  def do_checkNetworkInterface(self, s):
    """
    Checks the network interface using the IP address assigned to it.

    """
    self.process(self.paws.checkNetworkInterface(s))

  def do_getInstanceDistro(self, s):
    """
    Returns the distro name of an instance
    using the Amazon instance ID (tested)
    """
    self.process(self.paws.getInstanceDistro(s))

  def do_checkAMI(self, s):
    """
    Looks up all details on an AMI
    """
    self.process(self.paws.checkAMI(s))

  def do_checkInstance(self, s):
    """
    Checks instance status
    """
    self.process(self.paws.checkInstance(s))

  def do_createTag(self, s):
    """
    Arguments: 
    ID, name, value.

    Tags the resource with the ID with the name,value pair.
    """
    self.process(self.paws.createTag(s.split()))

  def do_resolveInstance(self, s):
    """
    Checks instance status

    Using Amazon ID (tested)
    """
    self.process(self.paws.resolveInstance(s))

  def do_displayInstance(self, s):
    """
    Displays the full gamut of instance attributes.

    Using Amazon ID (tested)
    """
    self.process(self.paws.displayInstance(s))

  def do_displayInterface(self, s):
    """
    Displays the full gamut of interface attributes.

    Using Amazon ID (tested)
    """
    self.process(self.paws.displayInterfaces(s))

  def do_displayImage(self, s):
    """
    Displays the full gamut of image attributes.

    Using Amazon ID (tested)
    """
    self.process(self.paws.displayImage(s))

  def do_getDistroAMIs(self, s):
    """
    Get the list of AMIs tagged for a distro.
    """
    self.process(self.paws.getDistroAMIs(s))

  def do_launchInstance(self, s):
    """
    Launch once instance:

    arguments: AMI ID, IP address, hostname. (tested)
    """
    (ami, ip, hostname) = s.split(' ')
    instance = self.paws.launchInstance(ami, ip=ip)
    self.paws.createTag(instance.id, 'Name', hostname)
    self.process(instance)

  def do_shutDownInstance(self, s):
    """
    Shuts down instance.

    Using Amazon ID (tested)
    """
    self.process(self.paws.shutDownInstance(s))

  def do_shutDownHost(self, s):
    """
    Shuts down instance.

    Using hostname (tested)
    """
    self.process(self.paws.shutDownHost(s))

  def do_checkAMIUpload(self, s):
    """
    checks if an AMI has uploaded.
    """
    self.process(self.paws.checkAMIUpload(s))

  def do_createTag(self, s):
    """
    Add a tag to a resource. 
    Args: ID, name, value
    """
    (Id, name, value) = s.split()
    self.paws.createTag(Id, name, value)


def getValidDistros():
  """
  Returns an array of the distros that we can work with on the basis of
  the contents of the scripts directory provided.

  @param directory The directory of configuration scripts.

  @return An array of names of distros that can be configured.
  """
  results = set(
    map(
      lambda x: os.path.basename(x),
      glob.glob(SCRIPTS_DIR + "/*.sh")))
  results.remove("updateNfs.sh")
  return sorted(
    map(
      lambda x: x[:-3].upper(),
      results))


def main(args):
  p = OptionParser()
  p.add_option("-c",
               "--command",
               dest="command",
               action="store",
               default=None,
               )
  (options, arguments) = p.parse_args(args)
  c = PermabitAWS()
  c.ec2Connect()
  c.s3Connect()
  CLI = AWSCLI(c)
  if options.command:
    return CLI.onecmd(options.command)
  else:
    CLI.cmdloop()

if __name__ == '__main__':
  main(sys.argv)
