#!/usr/bin/python

##
# Update the instances that are running in the cloud so that they are running
# the latest image and enough instances are running.
#
# $Id: //eng/main/src/python/Permabit/cloudUpdater.py#4 $
##
import os
import subprocess
import sys
import time

from AWSTools import *
from RSVP import *
from Logger import *
from ArchiveLogs import *

# Message that is used for RSVP messages
RESERVATION_MESSAGE = "Instance has been reserved for updating."

# The RSVP host to use when running
RSVP_HOST     = "rsvp-aws"

# The limit to the number of instances that the updater should work on
# at a single time
UPDATER_LIMIT = 5

# This is the user account to use when running
UPDATER_USER  = "updater"

# Constants that are used to track the state of the updates
OUTOFDATE     = "outOfDate",
UPDATED       = "updated",

AMI_2_DISTRO = {}

DISTRO_2_AMI = {}

updatedCounter = 0
updateLaterCounter = 0
upToDateCounter = 0
noDistroCounter = 0

def _buildAmiList(paws, logger):
  """
  Build dictionary of distros and versions.
  """
  amis = {}
  for distro in getValidDistros():
    results = paws.getDistroAMIs(distro)
    amis[distro]=results[-1]
    for result in results:
      AMI_2_DISTRO[result.id] = distro
    DISTRO_2_AMI[distro] = results[-1].id
    logger.info("%s, %s, %s, %s"%(
        distro, result, result.id, result.name))
  return amis

def _getDistroFromClasses(hostname, classes, logger):
  """
  Given a list of classes which an afarm belongs to
  return the first class found that is a valid distro,
  or None if none found.
  """
  for possibleDistro in getValidDistros():
    for cls in classes:
      if (None != re.search(possibleDistro, cls)):
        logger.info("distro=%s" % possibleDistro)
        return possibleDistro
  logger.warning("RSVP cannot determine distro for %s.  Not updating"
                 % hostname)
  return None

def _getAddressFromHostname(hostname, instance):
  """
  Use last part of the afarm-XXX hostname to determine its IP address.
  """
  afarmWithExtraZeroes = re.search('^afarm-[0]+(\d+)$', hostname)
  afarmWithoutExtraZeroes = re.search('^afarm-([1-9]\d*)$', hostname)
  if (afarmWithExtraZeroes is not None):
    return '10.250.1.' + afarmWithExtraZeroes.group(1)
  elif (afarmWithoutExtraZeroes is not None):
    return '10.250.1.' + afarmWithoutExtraZeroes.group(1)
  elif (instance is not None):
    return instance.private_ip_address
  else:
    return None

def _shutDownOldInstance(paws, instance, hostname, ipaddr, logger):
  """
  If there is an instance running the old version, shut it down
  and wait until it releases the private IP address so the new
  instance can use the private IP address.
  """
  if (instance is not None):
    logger.info("Shutting down old version of %s." % hostname)
    paws.shutDownAndWait(instance.id)
    logger.info("Shutdown succeeded.  Awaiting release of IP address.")
    until = datetime.datetime.now() + datetime.timedelta(minutes=15)
    while True:
      status = paws.checkNetworkInterface(ipaddr)
      logger.info("Network interface status: %s" % status)
      if not status:
        break
      if status != 'in-use':
        break
      if datetime.datetime.now() > until:
        logger.error("Gave up on address.")
        sys.exit(1)
      time.sleep(15)
    time.sleep(15)

def _updateInstances(rsvp, paws, updaterReservations, logger,
                     afarmsToProcess):
  """
  Update the instances that are reserved to the newest AMI.

  Determine the distro from the RSVP classes.  Skip if there is none.
  Get IP address from the hostname because terminated instances have none.
  Assume terminated instances should be updated no matter what
  distro they used to run.
  If cloudUpdater updates an afarm because UPDATER_USER had reserved
  this afarm before running cloudUpdater, there is no need to process it
  again, so remove it from afarmsToProcess if it is found there.
  Prevent two instances with the same name tag by removing the name
  from the old one.
  """
  reservations = rsvp.listHosts(user=UPDATER_USER, verbose=1)['data']
  for hostname, classes in reservations.items():
    logger.info( "Processing %s" % hostname)
    if updaterReservations.get(hostname) == UPDATED:
      continue
    instance = paws.getInstanceID(hostname)
    distro = _getDistroFromClasses(hostname, classes, logger)
    if (distro is None):
      updaterReservations[hostname] = UPDATED
      global noDistroCounter
      noDistroCounter = noDistroCounter + 1
      continue
    if (instance is not None and instance.state != 'terminated'):
      if instance.image_id == DISTRO_2_AMI[distro]:
        logger.info("%s already updated." % hostname)
        updaterReservations[hostname] = UPDATED
        global upToDateCounter
        upToDateCounter = upToDateCounter + 1
        continue
    ipaddr = _getAddressFromHostname(hostname, instance)
    # Create ArchiveLogs object and call it to perform archive
    archiver = ArchiveLogs(hostname)
    archiver.archiveLogs()
    _shutDownOldInstance(paws, instance, hostname, ipaddr, logger)
    oldInstance = instance
    logger.info("About to launch %s" % hostname)
    instance = paws.launchInstance(amiName=DISTRO_2_AMI[distro],
                                   ip=ipaddr)
    logger.info("Launched new instance of %s with id %s at %s" %
                (hostname, instance.id, instance.private_ip_address))
    if (afarmsToProcess.count(hostname) != 0):
      afarmsToProcess.remove(hostname)
    paws.createTag(instance.id, 'Name', hostname)
    updaterReservations[hostname] = UPDATED
    if (oldInstance is not None):
      paws.deleteTag(oldInstance.id, 'Name')
    global updatedCounter
    updatedCounter = updatedCounter + 1

def _releaseInstances(rsvp, paws, updaterReservations, logger):
  """
  Check to make sure instances that are currently reserved have been
  updated and if so, make sure they pass checkServer before releasing them
  back into use.

  @param rsvp The RSVP client to use.
  """
  until = datetime.datetime.now() + datetime.timedelta(minutes=15)
  while updaterReservations:
    for hostname in updaterReservations.keys():
      # Give up if this has been trying for too long
      if datetime.datetime.now() > until:
        logger.error("_releaseInstances ran out of time without releasing " +
                    ','.join(updaterReservations.keys() + '.'))
        sys.exit(1)
        return;
      # Make sure the reservation has been updated
      if updaterReservations[hostname] != UPDATED:
        continue
      # See if we can run checkserver on the instance,
      # if it passes, then release
      # the instance
      logger.info("About to run checkServer on %s" % hostname);
      message = rsvp.runAthinfo(hostname, "checkServer")
      if 'success' in message[0]:
        logger.info("CheckServer success.  Releasing.");
        rsvp.releaseHost(hosts=[hostname], user=UPDATER_USER)
        updaterReservations.pop(hostname)
      else:
        logger.error("CheckServer failure on %s" % hostname)

def _reserveInstances(rsvp, paws, updaterReservations, logger,
                      afarmsToProcess):
  """
  Reserve instances that need to be updated. If we can not grab then now,
  add the UPDATER_USER as the next user of the instance.
  """
  logger.info ('%s afarm(s) left to process' % len(afarmsToProcess))
  while (len(afarmsToProcess) != 0) :
    if len(updaterReservations.keys()) >= UPDATER_LIMIT:
      return
    else:
      host = afarmsToProcess.pop()
      try:
        rsvp.reserveHostByName(
          host=host,
          user=UPDATER_USER,
          msg="Reserving to update OS Image")
        updaterReservations[host] = OUTOFDATE
      except (RSVPError, NotEnoughHosts), e:
        try:
          logger.info("Could not reserve %s\n%s" % (host, e))
          reservations = rsvp.listHosts(hostRegexp=host, verbose=1)['data']
          for hostname, classes in reservations.items():
            instance = paws.getInstanceID(hostname)
            distro = _getDistroFromClasses(hostname, classes, logger)
            if (distro is not None):
              if instance.image_id != DISTRO_2_AMI[distro]:
                logger.info("Adding updater as next user.")
                rsvp.addNextUser(host=host, 
                                 user=UPDATER_USER, 
                                 msg="Reserving later to update OS Image.")
                global updateLaterCounter
                updateLaterCounter = updateLaterCounter + 1
              else:
                logger.info("%s is already up to date." % host)
                global upToDateCounter
                upToDateCounter = upToDateCounter + 1
        except (RSVPError, NotEnoughHosts), e:
          logger.info("Could not add next user for %s\n%s" % (host, e))

def _checkForExtraInstances(paws, afarmsToProcess, logger):
  """
  Log warnings if afarm instance exists in AWS but not in RSVP
  """
  instances = paws.getInstances()
  for instance in instances:
    name = instance.tags.get('Name', '')
    if (None != re.search('^afarm-\d+$', name)):
      if (0 == afarmsToProcess.count(name)):
        logger.warning("%s is an afarm instance in AWS but not in RSVP."
                       % name)

def _logStats(logger):
  """
  Record values of counters in the log
  """
  global updatedCounter
  global updateLaterCounter
  global upToDateCounter
  global noDistroCounter
  if (updatedCounter == 1):
    logger.info("STAT: " + str(updatedCounter) + 
                " host was successfully updated.")
  else:
    logger.info("STAT: " + str(updatedCounter) + 
                " hosts were successfully updated.")
  if (updateLaterCounter == 1):
    logger.info("STAT: " + str(updateLaterCounter) + 
                " host is in use and will be updated later.")
  else:
    logger.info("STAT: " + str(updateLaterCounter) + 
                " hosts are in use and will be updated later.")
  if (upToDateCounter == 1):
    logger.info("STAT: " + str(upToDateCounter) + 
                " host is already up to date.")
  else:
    logger.info("STAT: " + str(upToDateCounter) + 
                " hosts are already up to date.")
  if (noDistroCounter == 1):
    logger.info("STAT: " + str(noDistroCounter) + 
                " host had no recognizable distro defined in RSVP.")
  else:
    logger.info("STAT: " + str(noDistroCounter) + 
                " hosts had no recognizable distro defined in RSVP.")

def main(args):
  """
  Update the running afarm instances in the cloud to the newest AMI image
  that is running.
  """
  logger = getLogger("CloudUpdater")
  paws = PermabitAWS()
  paws.ec2Connect()
  rsvp = RSVP(dhost=RSVP_HOST)
  amiList = _buildAmiList(paws, logger)
  updaterReservations = {}
  afarmsToProcess= rsvp.listHosts(hostRegexp='afarm-\\d+')['data'].keys()
  _checkForExtraInstances(paws, afarmsToProcess, logger)
  while True:
    _updateInstances (rsvp, paws, updaterReservations, logger,
                      afarmsToProcess)
    _releaseInstances(rsvp, paws, updaterReservations, logger)
    _reserveInstances(rsvp, paws, updaterReservations, logger,
                      afarmsToProcess)
    if len(updaterReservations) == 0:
      _logStats(logger)
      sys.exit(0)

if __name__ == '__main__':
  main(sys.argv)
