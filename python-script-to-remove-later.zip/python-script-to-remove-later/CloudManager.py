#!/usr/bin/python 
#
#
from AWSTools import PermabitAWS
from RSVP import RSVP
import sys
import time
import subprocess 


class CloudManager(object):
  """
  Lets you test taking down and 
  creating new AWS instances. 
"""
  
  private_key = "/permabit/ops/ec2/pk-permabit.pem"
  private_cert = "/permabit/ops/ec2/cert-permabit.pem"
  # @ple The hose to run the command line tools from.
  host    = "porter-89"
  # @ple The IP block that the instances run on.
  ipBlock = "10.250.1"
  # @ple The RSVP host to use 
  rsvp    = "rsvp-aws"
  # @ple The user that should be used to hold off line instances.
  user    = "OFFLINE"

  def __init__(self, instances, host_=None, user_=None):
    self.instances = instances
    if host_:
      self.host = host_
    if user_: 
      self.user = user_
    self._getAWS()

  def currentBalances(self, rsvp):
    """
    Get the current balances for the distributions that need to be 
    managed.

    @param rsvp The RSVP host connection to use.
 
    @return A hash that contains the distributions as the key with sub-hashes
    that contain an off line and total field that contains the number of
    instances of the given type that are off line and the total number 
    registered, respectively.
    
    """
    balances = {}
    for distro in self.instances.keys():
      total = len(rsvp.listHosts(hostClass=distro)['data'])
      offline = len(rsvp.listHosts(hostClass=distro, user=self.user)['data'])
      balances[distro] = {'total': total, 'offline': offline}
    return balances

  def getAmi(self, distro):
    """
    Get the most recent AMI for the distribution provided.

    @param distro The distribution name to look up.

    @return The most recent EC2 AMI.
    works. 
"""
    L = self.AWS.conn.get_all_images(filters={"tag:Distro": distro})
    L.sort(key = lambda i: i.name)
    return L[-1]

  def _getAWS(self):
    self.AWS = PermabitAWS()
    self.AWS.ec2Connect()

  def _launchInstance(self, ami, ip, name): 
    """
    Launch an EC2 instance of the given AMI type with the IP and name
    provided.
    
    @param ami The EC2 AMI that should be launched.
    @param ip The private ip address of the instance to be launched.
    @param name The host name of the instance.
    
    @return None
    False (0) if the instance failed to launch, true (1) otherwise.
    
"""
    R = self.AWS.launchInstance(ami, ip=ip)
    print R
    instance = R.instances[0]
    print instance
    self.AWS.conn.create_tags([instance.id], {"Name": name})
    print name

  def _releaseReservations(self, hosts, rsvp):
    """
    Monitor the hosts indicated until they are ready to be released from
    RSVP. This function may take a considerable amount of time before it
    returns, but since all of the instances are launched in parallel the
    times will most likely be between five and fifteen minutes.
    
    @param hosts A reference to the array of hosts to be released.
    @param rsvp The RSVP connection to use.
    """
    working = list(hosts)
    while working: 
      for host in working: 
        P = subprocess.Popen(["athinfo", host, "checkserver"],
                             stdout=subprocess.PIPE)
        (result, stderr) = P.communicate()        
        if result.lstrip().startswith("success"):
          rsvp.releaseHost(hosts=[host], user=self.user)
          working.remove(host)
      time.sleep(5)

  def start(self):
    """
    Start cloud instances that are currently reserved by the off line 
    user until such time that the maximum needed for the given 
    distribution are on line. This function does not return until the 
    instances are on line and have been released.
    """
    rsvp = RSVP(dhost=self.rsvp)
    hosts = []
    fails = []
    balances = self.currentBalances(rsvp)
    for distro, figures in balances.items():
      print distro, rsvp.listHosts(
        hostClass=distro, user=self.user)
      # Get the instances that are currently off line
      reservations = rsvp.listHosts(
        hostClass=distro, user=self.user)['data'].keys()

      if not reservations: 
        continue
      ami = self.getAmi(distro).id
      print reservations, ami

      for reservation in reservations: 
        try:
          if not reservation.startswith('afarm-'): 
            print "error", reservation
            continue
          # launch it. 
          ip = reservation[6:]
          print "LAUNCH", reservation, ip, ami
          self._launchInstance(
            ami, self.ipBlock + '.' + ip, reservation)
          hosts.append(reservation)
          figures['offline'] -= 1
        except Exception, e:
          print e
          fails.append(reservation)
    if hosts: 
      self._releaseReservations(hosts, rsvp)
    if fails: 
      print "Failed with ", fails

  def stop(self):
    """
    Stop instances until such time that we are either at the minimum for
    each of the distributions or all of the remaining instances are 
    currently in use.
    """
    rsvp = RSVP(dhost=self.rsvp)
    hosts = []
    balances = self.currentBalances(rsvp)
    stopped = False
    for distro, numbers in balances.items():
      online = numbers['total'] - numbers['offline']
      target = self.instances[distro]['minimum']

      if online <= target:
        continue

      while online > target:
        print online, target, numbers, distro
        reservation = rsvp.reserveHostsByClass({
          'numhosts': 1,
          'class': distro,
          'user': self.user})
        print "stopping %s" % reservation[0]
        self._terminateHost(reservation[0])
        online -= 1 
        stopped = True
    return stopped

  def _terminateHost(self, host):
    """#
    Shutdown the instance indicated.

    @param host The host name to be shutdown.

    """
    instance = self.AWS.getInstanceID(name=host)
    print self.AWS.shutDownAndWait(instance.id)


def main(args): 
  """RUNS THE CLOUD MANAGER TEST
  """
  R = RSVP(dhost="rsvp-aws",)
  L = R.listHosts(hostClass="SQUEEZE")
  total = len(L['data'])
  C = CloudManager(instances={"SQUEEZE": {"minimum": total - 1,
                                          "maximum": total}},
                   user_="OFFLINE_TEST")
  print C.currentBalances(R)
  ami= C.getAmi('SQUEEZE')
  print ami, ami.name
  #if C.stop():
  #  time.sleep(90)
  #C.start()

if __name__ == '__main__':
  main(sys.argv)

