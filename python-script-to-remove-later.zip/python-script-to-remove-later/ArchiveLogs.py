#!/usr/bin/python
#
# Script to archive specific directories to /permabit/not-backed-up directory
# Before cloud systems are terminated
# The following log directories and sub-directories are to be archived
# /var, /config, /etc, /boot
# except for /var/lib, /var/cache, /var/spool
# Cloud servers are backed up to nfs-06

from Logger import *
import pipes
import subprocess
import time
import os

archiveRoot = '/permabit/not-backed-up/log-archive'
chmod = '/bin/chmod'
chown = '/bin/chown'
exclude_dir = ['/var/lib', '/var/cache', '/var/spool']
log_directories = ['/var', '/config', '/etc', '/boot']
mkdir = '/bin/mkdir'
tar = '/bin/tar'

# Preparing logging
logger = getLogger("ArchiveLogs")

class ArchiveLogs(object):
  """
  Class representing ArchiveLogs
  create archives of specific directories
  """

  def __init__(self, hostname):
    """
    Initializer sets hostname, timeStamp, and outputDirectory
    :param hostname: (str) cloud system to reach
    :return: Nothing
    """
    self.hostname = hostname
    self.timeStamp = time.strftime("%Y-%m-%d-%H-%M")
    hostDirectory = archiveRoot + "/" + self.hostname
    self.outputDirectory = hostDirectory + "/" + self.timeStamp

  def sshRunCommand(self, command):
    """
    ssh and run command to host that needs to have directories tar.gz
    :param command: (str) command to be executed
    :return: Nothing
    """
    ssh = subprocess.Popen(["ssh", "%s" % self.hostname, "%s" % command],
                            shell=False,
                            stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE)
    result = ssh.stdout.readlines()

    if result == []:
      error = ssh.stderr.readlines()
      if error:
        logger.error("ERROR: %s" % error)
      else:
        logger.info("ssh task in progress")


  def archiveLogs(self):
    """
    Archive directories specified
    :return:nothing
    """
    # Creating output directory
    try:
      logger.info("Creating %s" % self.outputDirectory)
      self.sshRunCommand("sudo %s -p %s " % (mkdir, self.outputDirectory))
    except OSError as e:
      logger.error("ERROR: %s" % e.errno)
      pass

    # Archive the directories
    for directory in log_directories:
      logger.warning("Processing %s" % directory)
      self.saveLog(directory)

    # Set ownership and permission on the directory
    self.sshRunCommand("sudo %s -R root:staff %s " % 
                      (chown, self.outputDirectory))
    self.sshRunCommand("sudo %s -R 755 %s " % (chmod, self.outputDirectory))


  def saveLog(self, directoryName):
    """
    Save the log files by generating the tar.gz file
    The generated tar.gz file will be saved to the archiveRoot directory
    :param directoryName: (str) directory to archive
    :return: Nothing
    """
    # Verify that the directory really exists
    response = subprocess.call (
            ['ssh', self.hostname, 'test -e ' +
             pipes.quote(self.outputDirectory)])
    if (response != 0):
      logger.warning("""The directory %s does not exist,
              skipping.""" % self.outputDirectory)
      return

    # Prepare the directories that are going to be archived
    tarFile = (self.timeStamp + "." + self.hostname + "." + directoryName[1:]
              + ".tar.gz")
    tarDirectory = archiveRoot + "/" + self.hostname + "/" + self.timeStamp

    # Save the logs to the archive
    exclude_CMD = [ " --exclude=%s" %x for x in exclude_dir]
    exclude_CMD = "".join(exclude_CMD)
    logger.info("Saving %s to %s from %s" % (tarFile,
                                             archiveRoot, directoryName))

    self.sshRunCommand("sudo %s czvf %s/%s %s %s" % (tar, tarDirectory,
                                                     tarFile, directoryName,
                                                     exclude_CMD))
