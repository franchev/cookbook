#!/bin/bash

##
## Install Docker
##
apt-key adv --keyserver hkp://pgp.mit.edu:80 --recv-keys 58118E89F3A912897C070ADBF76221572C52609D
echo "deb https://apt.dockerproject.org/repo ubuntu-trusty main" > /etc/apt/sources.list.d/docker.list
apt-get update
apt-get purge lxc-docker*
apt-cache policy docker-engine
apt-get install -y docker-engine
apt-get install -y puppet

##
## Puppet
##
puppet agent --enable
service puppet stop
rm -f /etc/init.d/puppet

##
## Install Cassandra
## http://docs.datastax.com/en/cassandra/2.0/cassandra/install/installDeb_t.html
##
apt-get update
apt-get install -y curl
echo "deb http://debian.datastax.com/community stable main" | tee /etc/apt/sources.list.d/dsc.list
curl -L http://debian.datastax.com/debian/repo_key | apt-key add -
apt-get update
apt-get install -y openjdk-7-jdk libjna-java
mkdir -p /usr/share/cassandra/lib
ln -s /usr/share/cassandra/lib/jna.jar /usr/share/java/jna.jar

apt-get install -y cassandra=2.2.3 dsc22
service cassandra stop
rm -rf /var/lib/cassandra/data/system/*
# edit /etc/cassandra/cassandra.yaml
# Change the addresses to the value of eth0
# nodetool status
# nodetool ring

apt-get install -y datastax-agent
service datastax-agent start

apt-get install -y opscenter
service opscenterd start
# http://opscenter-host:8888/



